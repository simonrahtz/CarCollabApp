package com.test.sharecar.presentation.activities.order;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RelativeLayout;

import com.test.sharecar.R;

public class AllOrderActivity extends AppCompatActivity {

    private RelativeLayout mRlOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_order);

        mRlOrder = findViewById(R.id.rl_order);
        mRlOrder.setOnClickListener(v -> {
            startActivity(new Intent(this, OrderDetailActivity.class));
        });
    }
}